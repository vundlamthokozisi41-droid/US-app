# 💛 How to Put Your Love App Online — Step by Step (Like You're 5)

## What you need first
- A computer (phone won't work for setup)
- An email address

---

## STEP 1: Create a GitHub account (free!)

1. Open your internet browser (Chrome, Firefox, etc.)
2. Go to: **https://github.com**
3. Click the big green button **"Sign up"**
4. Type in your email address
5. Create a password
6. Pick a username (like `mthokozisi` or anything you like)
7. Click through the steps and verify your email

---

## STEP 2: Create a new "home" for your app on GitHub

1. After logging in, look for a **"+"** button at the top right
2. Click it, then click **"New repository"**
3. In the box that says "Repository name", type exactly: **us-app**
4. Make sure **"Public"** is selected (this is so GitHub can host it for free)
5. Check the box that says **"Add a README file"**
6. Click the green button **"Create repository"**

---

## STEP 3: Upload your files

You have 3 files:
- `index.html`
- `manifest.json`
- `sw.js`

1. You should now be on a page that shows your new repository
2. Click the button that says **"Add file"** → then **"Upload files"**
3. Drag and drop ALL THREE files onto the page (or click "choose your files")
4. Scroll down and click the green **"Commit changes"** button
5. Wait a few seconds — your files are now uploaded! 🎉

---

## STEP 4: Turn it into a real website (GitHub Pages)

1. On your repository page, click **"Settings"** (top menu, gear icon)
2. On the left side, scroll down and click **"Pages"**
3. Under "Source", click the dropdown that says **"None"**
4. Select **"main"** (or "master" if that's what shows)
5. Click **"Save"**
6. Wait about 2 minutes
7. Refresh the page — you'll see a message like:
   **"Your site is live at https://YOUR-USERNAME.github.io/us-app/"**

That link IS your app! 🌍

---

## STEP 5: Open it on your phone

1. Copy the link: `https://YOUR-USERNAME.github.io/us-app/`
2. Open it on your phone in Chrome (Android) or Safari (iPhone)
3. **To install it as an app:**
   - **Android/Chrome:** Tap the 3 dots menu → "Add to Home screen" → "Add"
   - **iPhone/Safari:** Tap the share icon (box with arrow) → "Add to Home Screen" → "Add"
4. It will now appear on your phone like a real app! 📱

---

## STEP 6: Set it up inside the app

1. Open the app
2. Tap **"Setup"** at the bottom
3. Type YOUR name and HER name
4. Type the date you first got together
5. Tap **"Enable"** on the notification banner so you get reminders
6. Share the same link with her — she can also open it and add it to her phone!

---

## STEP 7: Give her the link

Just send her the link:
`https://YOUR-USERNAME.github.io/us-app/`

She opens it on her phone, adds it to her home screen, and you two can message each other through it! 💛

---

## What the app does:
✅ Counts your years, months, weeks, days & minutes together  
✅ Shows when your next monthly anniversary is  
✅ Sends a notification on your anniversary day every month  
✅ You can message each other inside the app  
✅ Pop-up notifications when messages are sent  
✅ Works offline once installed  
✅ Feels like a real phone app  

---

## If you get stuck
- Make sure all 3 files are uploaded
- Make sure you enabled GitHub Pages (Step 4)
- Wait 2–5 minutes after enabling Pages before the link works

---

*Built with love, for love. lerato fela. 💛*
